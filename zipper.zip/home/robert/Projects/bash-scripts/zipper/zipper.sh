#!/bin/bash
for file in $1/*
do
	if [[ $file =~ \.zip$ ]]; then
		continue
	fi

	zip -r $file.zip $file
done
