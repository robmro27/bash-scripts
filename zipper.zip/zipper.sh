#!/bin/bash
for file in $1/*
do
	if [[ $file =~ \.zip$ ]]; then
		continue
	fi

	zip -rj $file.zip $file
done
