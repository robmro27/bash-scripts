#!/bin/sh
for file in $1
do
	if grep -q .zip$ "$file"; then
  		"Ommiting $file"
	fi
	echo "Zipping file: $file"
	zip -r $file.zip $file
done
